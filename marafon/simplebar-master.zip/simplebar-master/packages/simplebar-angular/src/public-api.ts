/*
 * Public API Surface of simplebar-angular
 */

export * from './lib/simplebar-angular.component';
export * from './lib/simplebar-angular.module';
