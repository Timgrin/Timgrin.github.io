document.querySelector('.header-burgerMenu').addEventListener('click', function() {
document.querySelector('.menu-icon').classList.toggle('menu-icon-active');
});